insert into TRAFFIC_DISRUPTION values (1);
