package com.trapeze.tfl.service;

import com.trapeze.tfl.repository.DisruptionRepository;
import com.trapeze.tfl.service.dto.DisruptionDTO;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.time.LocalDateTime;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
@Slf4j
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@DataJpaTest
public class TflDisruptionHandlerTest {

    @Autowired
    private DisruptionRepository disruptionRepository;

    @MockBean
    private TflDisruptionService tflDisruptionService;

    private TflDisruptionHandler testSrv;

    @BeforeAll
    public void prepare(){
        testSrv = new TflDisruptionHandler(tflDisruptionService, disruptionRepository);
    }

    @Test
    public void shouldProcessUniqueDisruptionList(){
        //given
        var dis1 = DisruptionDTO.builder()
                .description("description 1")
                .created(LocalDateTime.of(2023, 12, 12, 12 ,13))
                .build();
        var dis2 = DisruptionDTO.builder()
                .description("description 2")
                .created(LocalDateTime.of(2023, 12, 12, 12 ,12))
                .build();
        var apiResponse = List.of(dis1, dis2);

        //when
        when(tflDisruptionService.disruptions("bus")).thenReturn(apiResponse);

        testSrv.updateDisruptionByMode("bus");

        //then
        var result = disruptionRepository.findDisruptionByMode("bus");
        assertEquals(2, result.size());
        assertTrue(result.stream().filter(p -> p.getDescription().equals(dis1.getDescription())).findAny().isPresent());
        assertTrue(result.stream().filter(p -> p.getDescription().equals(dis2.getDescription())).findAny().isPresent());
        assertNotEquals(result.stream().filter(p -> p.getDescription().equals(dis1.getDescription())).findAny().get().getHash(),
                result.stream().filter(p -> p.getDescription().equals(dis2.getDescription())).findAny().get().getHash());

    }

    @Test
    public void shouldProcessUpdatedDisruptionList(){
        //given
        var dis1 = DisruptionDTO.builder()
                .description("description 1")
                .created(LocalDateTime.of(2022, 10, 10, 10 ,10))
                .build();
        var dis2 = DisruptionDTO.builder()
                .description("description 2")
                .created(LocalDateTime.of(2022, 10, 10, 10 ,11))
                .build();
        var dis3 = DisruptionDTO.builder()
                .description("description 3")
                .created(LocalDateTime.of(2022, 10, 10, 10 ,11))
                .build();
        var firstApiResponse = List.of(dis1, dis2);
        var secondApiResponse = List.of(dis1, dis3);
        //when
        when(tflDisruptionService.disruptions("bus")).thenReturn(firstApiResponse);
        when(tflDisruptionService.disruptions("bus")).thenReturn(secondApiResponse);

        testSrv.updateDisruptionByMode("bus");

        //then
        var result = disruptionRepository.findDisruptionByMode("bus");
        assertEquals(2, result.size());
        assertTrue(result.stream().filter(p -> p.getDescription().equals(dis1.getDescription())).findAny().isPresent());
        assertTrue(result.stream().filter(p -> p.getDescription().equals(dis3.getDescription())).findAny().isPresent());
        assertFalse(result.stream().filter(p -> p.getDescription().equals(dis2.getDescription())).findAny().isPresent());
        assertNotEquals(result.stream().filter(p -> p.getDescription().equals(dis1.getDescription())).findAny().get().getHash(),
                result.stream().filter(p -> p.getDescription().equals(dis3.getDescription())).findAny().get().getHash());
    }

}
