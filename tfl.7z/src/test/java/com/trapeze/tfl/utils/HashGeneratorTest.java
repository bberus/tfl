package com.trapeze.tfl.utils;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

public class HashGeneratorTest {

    @Test
    public void shouldGenerateSameHashForSameParam(){
        String toHash = "qwerty";

        assertEquals(HashGenerator.calculateHash(toHash), HashGenerator.calculateHash(toHash));
    }

    @Test
    public void shouldGEnerateDifferentHash(){
        String toHash1 = "qwerty1";
        String toHash2 = "qwerty2";
        assertNotEquals(HashGenerator.calculateHash(toHash1), HashGenerator.calculateHash(toHash2));
    }
}
