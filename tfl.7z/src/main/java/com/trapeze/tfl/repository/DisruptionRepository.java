package com.trapeze.tfl.repository;

import com.trapeze.tfl.model.Disruption;
import org.springframework.data.repository.CrudRepository;

import java.util.List;
import java.util.Optional;

public interface DisruptionRepository extends CrudRepository<Disruption, Long> {

    Optional<Disruption> findByHash(String hash);

    List<Disruption> findDisruptionByMode(String mode);

}