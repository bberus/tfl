package com.trapeze.tfl.controller;

import com.trapeze.tfl.service.TflDisruptionHandler;
import com.trapeze.tfl.service.dto.DisruptionDTO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Slf4j
@RestController
public class DisruptionController {

    private TflDisruptionHandler handler;

    @GetMapping("/disruptions/{mode}")
    public List<DisruptionDTO> listDisruption(@PathVariable String mode){
        log.info("Listing disruption by mode {}", mode);
        return handler.listDisruption(mode);
    }

}
