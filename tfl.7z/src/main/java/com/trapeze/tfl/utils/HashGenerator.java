package com.trapeze.tfl.utils;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.httpclient.util.EncodingUtil;

import javax.xml.bind.DatatypeConverter;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.UUID;

/**
 * Utility class that provides method for hash generation
 * @author bberus
 * 
 */
@Slf4j
public class HashGenerator {

	/**
	 * Calculates hash on the top of provided message to hash and SHA hashing
	 * algorithm
	 * 
	 * @param message
	 *            - message to hash, eg. password
	 * @return generated Hash
	 */
	public static String calculateHash(String message) {
		try {
			log.debug(
					"[calculateHash] trying to generate hash for message {} characters long",
					message.length());
			MessageDigest md = MessageDigest.getInstance("SHA");
			md.update(EncodingUtil.getBytes(message, "UTF-8"));
			String result = DatatypeConverter.printHexBinary(md.digest())
					.toLowerCase();
			log.debug("[calculateHash] Generated {} characters long",
					result.length());
			return result;
		} catch (NoSuchAlgorithmException e) {
			log.error("[calculateHash] Error trying generate hashlink");
			throw new RuntimeException("Error trying generate hashlink", e);
		}
	}

	/**
	 * Generates hash on the top of UUID and SHA hashing algorithm
	 * 
	 * @return generated Hash
	 */
	public static String generateHash() {
		log.debug("[generateHash] trying to generate hash");
		String uniqueKey = UUID.randomUUID().toString();
		String result = calculateHash(uniqueKey);
		log.debug("[generateHash] Generated {} characters long",
				result.length());
		return result;
	}

}
