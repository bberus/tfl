package com.trapeze.tfl.service.dto;

import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Generated;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.NoArgsConstructor;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "$type",
        "category",
        "type",
        "categoryDescription",
        "description",
        "additionalInfo",
        "created",
        "lastUpdate",
        "affectedRoutes",
        "affectedStops"
})
@Generated("jsonschema2pojo")
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DisruptionDTO {

    @JsonProperty("$type")
    private String $type;
    @JsonProperty("category")
    private String category;
    @JsonProperty("type")
    private String type;
    @JsonProperty("categoryDescription")
    private String categoryDescription;
    @JsonProperty("description")
    private String description;
    @JsonProperty("additionalInfo")
    private String additionalInfo;
    @JsonProperty("created")
    private LocalDateTime created;
    @JsonProperty("lastUpdate")
    private LocalDateTime lastUpdate;
    @JsonProperty("affectedRoutes")
    private List<String> affectedRoutes;
    @JsonProperty("affectedStops")
    private List<String> affectedStops;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<String, Object>();

    @JsonProperty("$type")
    public String get$type() {
        return $type;
    }

    @JsonProperty("$type")
    public void set$type(String $type) {
        this.$type = $type;
    }

    @JsonProperty("category")
    public String getCategory() {
        return category;
    }

    @JsonProperty("category")
    public void setCategory(String category) {
        this.category = category;
    }

    @JsonProperty("type")
    public String getType() {
        return type;
    }

    @JsonProperty("type")
    public void setType(String type) {
        this.type = type;
    }

    @JsonProperty("categoryDescription")
    public String getCategoryDescription() {
        return categoryDescription;
    }

    @JsonProperty("categoryDescription")
    public void setCategoryDescription(String categoryDescription) {
        this.categoryDescription = categoryDescription;
    }

    @JsonProperty("description")
    public String getDescription() {
        return description;
    }

    @JsonProperty("description")
    public void setDescription(String description) {
        this.description = description;
    }

    @JsonProperty("additionalInfo")
    public String getAdditionalInfo() {
        return additionalInfo;
    }

    @JsonProperty("additionalInfo")
    public void setAdditionalInfo(String additionalInfo) {
        this.additionalInfo = additionalInfo;
    }

    @JsonProperty("created")
    public LocalDateTime getCreated() {
        return created;
    }

    @JsonProperty("created")
    public void setCreated(LocalDateTime created) {
        this.created = created;
    }

    @JsonProperty("lastUpdate")
    public LocalDateTime getLastUpdate() {
        return lastUpdate;
    }

    @JsonProperty("lastUpdate")
    public void setLastUpdate(LocalDateTime lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    @JsonProperty("affectedRoutes")
    public List<String> getAffectedRoutes() {
        return affectedRoutes;
    }

    @JsonProperty("affectedRoutes")
    public void setAffectedRoutes(List<String> affectedRoutes) {
        this.affectedRoutes = affectedRoutes;
    }

    @JsonProperty("affectedStops")
    public List<String> getAffectedStops() {
        return affectedStops;
    }

    @JsonProperty("affectedStops")
    public void setAffectedStops(List<String> affectedStops) {
        this.affectedStops = affectedStops;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}