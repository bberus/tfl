package com.trapeze.tfl.service;

import com.trapeze.tfl.model.Disruption;
import com.trapeze.tfl.repository.DisruptionRepository;
import com.trapeze.tfl.service.dto.DisruptionDTO;
import com.trapeze.tfl.utils.HashGenerator;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.ZoneId;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

@Slf4j
@RequiredArgsConstructor
@Service
public class TflDisruptionHandler {

    private final TflDisruptionService tflDisruptionService;
    private final DisruptionRepository tflRepository;

    public void updateDisruptionByMode(String mode) {
        log.info("Updating disruption by mode: {}", mode);
        var result = tflDisruptionService.disruptions(mode);
        log.info("number of disruptions: {}, mode {}", result.size(), mode);
        result.stream().filter(disruption -> disruption != null).forEach(dis -> {
                    upsertDisruption(dis, mode);
                }
        );
    }

    public List<DisruptionDTO> listDisruption(String mode){
        return Collections.emptyList();
                //todo (tflRepository.findDisruptionByMode(mode));
    }

    public boolean validateModes(List<String> modes){
        //todo validate provided modes
        return true;
    }

    private void upsertDisruption(DisruptionDTO dis, String mode) {
        String uniqueHash = generateHash(dis);
        log.debug("processing disruption with hash: {}", uniqueHash);
        var disruption = tflRepository.findByHash(uniqueHash);
        upsert(dis, disruption, uniqueHash, mode);
    }

    private void upsert(DisruptionDTO dis, Optional<Disruption> existDisruption, String uniqueHash, String mode) {
        var disruption = Disruption.builder()
                .affectedRoutes(dis.getAffectedRoutes())
                .affectedStops(dis.getAffectedStops())
                .category(dis.getCategory())
                .description(dis.getDescription())
                .type(dis.getType())
                .tflLastUpdate(dis.getLastUpdate())
                .tflCreated(dis.getCreated())
                .mode(mode)
                .hash(uniqueHash);
        if (existDisruption.isPresent()) {
            disruption.id(existDisruption.get().getId());
        }
        tflRepository.save(disruption.build());
    }

    /**
     * Generating unique value for disruption
     *
     * @param dis
     * @return
     */
    private String generateHash(DisruptionDTO dis) {
        StringBuilder sb = new StringBuilder();
        if(dis.getCreated() != null) {
            sb.append(dis.getCreated().atZone(ZoneId.systemDefault()).toInstant().toEpochMilli());
        } else {
            sb.append(dis.getDescription());
        }
        return HashGenerator.calculateHash(sb.toString());
    }

}
