package com.trapeze.tfl.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.trapeze.tfl.service.dto.DisruptionDTO;
import com.trapeze.tfl.utils.TflRestClient;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import javax.annotation.PostConstruct;
import java.util.Collections;
import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class TflDisruptionService {

    private static HttpEntity<String> request;
    private static HttpHeaders headers;

    @Value("${tfl.endpoint}")
    private String tflEndpoint;

    private final ObjectMapper mapper;
    private final TflRestClient tflRestClient;

    public List<DisruptionDTO> disruptions(String mode){

        ResponseEntity<String> response = getRestClient().exchange(prepareUrl("/Line/Mode/%s/Disruption", mode),
                HttpMethod.GET,
                request, String.class);

       log.debug("Response: {}", response.getBody());

       return prepareResponse(response);
    }

    private List<DisruptionDTO> prepareResponse(ResponseEntity<String> response) {
        if(response.getStatusCode().is2xxSuccessful()){
            return handleSuccessResponse(response);
        }
        return handleError(response);
    }

    private List<DisruptionDTO> handleError(ResponseEntity<String> response) {
        log.error("Error during processing response, details: {}", response.getBody());
        return Collections.emptyList(); //todo
    }

    private List<DisruptionDTO> handleSuccessResponse(ResponseEntity<String> response) {
        try {
            return mapper.readValue(response.getBody(), new TypeReference<>() {});
        } catch (Exception e) {
            log.error("Error during processing response: {}", e.getMessage());
            throw new RuntimeException("Error during processing TFL response");
        }
    }

    private String prepareUrl(String resource, String... params) {
        return tflEndpoint + String.format(resource, params);
    }

    private RestTemplate getRestClient() {
        return tflRestClient.getClient();
    }

    private static void prepareHttpRequest() {
        if (request == null) {
            request = new HttpEntity<>(headers);
        }
    }

    private static HttpHeaders prepareHeaders() {
        if (headers == null) {
            headers = new HttpHeaders();
            headers.add("Content-Type", "application/json");
        }
        return headers;
    }

    @PostConstruct
    private void prepared() {
        prepareHeaders();
        prepareHttpRequest();
        log.info("TFL Rest client ready with URL: [{}]", tflEndpoint);
    }
}
