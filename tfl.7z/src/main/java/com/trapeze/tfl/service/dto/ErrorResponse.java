package com.trapeze.tfl.service.dto;

import java.util.LinkedHashMap;
        import java.util.Map;
        import javax.annotation.Generated;
        import com.fasterxml.jackson.annotation.JsonAnyGetter;
        import com.fasterxml.jackson.annotation.JsonAnySetter;
        import com.fasterxml.jackson.annotation.JsonIgnore;
        import com.fasterxml.jackson.annotation.JsonInclude;
        import com.fasterxml.jackson.annotation.JsonProperty;
        import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "$type",
        "timestampUtc",
        "exceptionType",
        "httpStatusCode",
        "httpStatus",
        "relativeUri",
        "message"
})
@Generated("jsonschema2pojo")
public class ErrorResponse {

    @JsonProperty("$type")
    private String $type;
    @JsonProperty("timestampUtc")
    private String timestampUtc;
    @JsonProperty("exceptionType")
    private String exceptionType;
    @JsonProperty("httpStatusCode")
    private Integer httpStatusCode;
    @JsonProperty("httpStatus")
    private String httpStatus;
    @JsonProperty("relativeUri")
    private String relativeUri;
    @JsonProperty("message")
    private String message;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<String, Object>();

    @JsonProperty("$type")
    public String get$type() {
        return $type;
    }

    @JsonProperty("$type")
    public void set$type(String $type) {
        this.$type = $type;
    }

    @JsonProperty("timestampUtc")
    public String getTimestampUtc() {
        return timestampUtc;
    }

    @JsonProperty("timestampUtc")
    public void setTimestampUtc(String timestampUtc) {
        this.timestampUtc = timestampUtc;
    }

    @JsonProperty("exceptionType")
    public String getExceptionType() {
        return exceptionType;
    }

    @JsonProperty("exceptionType")
    public void setExceptionType(String exceptionType) {
        this.exceptionType = exceptionType;
    }

    @JsonProperty("httpStatusCode")
    public Integer getHttpStatusCode() {
        return httpStatusCode;
    }

    @JsonProperty("httpStatusCode")
    public void setHttpStatusCode(Integer httpStatusCode) {
        this.httpStatusCode = httpStatusCode;
    }

    @JsonProperty("httpStatus")
    public String getHttpStatus() {
        return httpStatus;
    }

    @JsonProperty("httpStatus")
    public void setHttpStatus(String httpStatus) {
        this.httpStatus = httpStatus;
    }

    @JsonProperty("relativeUri")
    public String getRelativeUri() {
        return relativeUri;
    }

    @JsonProperty("relativeUri")
    public void setRelativeUri(String relativeUri) {
        this.relativeUri = relativeUri;
    }

    @JsonProperty("message")
    public String getMessage() {
        return message;
    }

    @JsonProperty("message")
    public void setMessage(String message) {
        this.message = message;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}