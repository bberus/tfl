package com.trapeze.tfl.scheduler;

import com.trapeze.tfl.service.TflDisruptionHandler;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.time.LocalDateTime;
import java.util.Arrays;

@Slf4j
@Component
@RequiredArgsConstructor
public class TflDisruptionScheduler {

    @Value("${tfl.disruption.modes}")
    private String modes;

    private final TflDisruptionHandler tflDisruptionHandler;

    @Scheduled(fixedDelayString = "${tfl.disruption.check.delay}")
    public void checkDisruption() {
       log.info("Checking disruption [{}]", LocalDateTime.now());
       Arrays.stream(modes.split(";"))
               .sequential().forEach(mode -> tflDisruptionHandler.updateDisruptionByMode(mode));
    }

    @PostConstruct
    private void onStartup() {
        log.info("TflDisruptionScheduler configured with modes: {}", modes);
        tflDisruptionHandler.validateModes(Arrays.asList(modes.split(";")));
    }

}
